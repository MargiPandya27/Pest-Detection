# mpmc1 > 2023-04-20 12:53am
https://universe.roboflow.com/animal-detection-rmslv/mpmc1

Provided by a Roboflow user
License: CC BY 4.0

