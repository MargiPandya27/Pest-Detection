# mpmc1 > 2023-04-20 8:31am
https://universe.roboflow.com/animal-detection-rmslv/mpmc1

Provided by a Roboflow user
License: CC BY 4.0

